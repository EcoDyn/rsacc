"colors.matrix" <-
  function(){
    x <- matrix(c(colors(),NA,NA,NA), 30, 22)
    invisible(x)
  }
